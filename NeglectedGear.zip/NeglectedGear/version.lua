-- Neglected Gear Copyright 2017 JontomXire@hushmail.com


local NeglectedGear = _G.NeglectedGear

NeglectedGear.major_version = 1;
NeglectedGear.minor_version = 4;


